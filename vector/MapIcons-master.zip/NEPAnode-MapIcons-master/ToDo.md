##############
#***To Do List***
# F: Fix
# D: Delete
##############

Gov-Webicons [ 81 icons ]
F  DOI-BLM.svg
F  gov-doc.svg
F  gov-dot.svg
F  gov-doj.svg
F  gov-hhs.svg
F  gov-interior.svg
F  gov-opm.svg
F  gov-pto.svg
F  gov-president.svg
F  gov-state.svg
F  gov-ssa.
F  gov-sba.svg
F  gov-treasury.svg
F  gov-va.svg

N_Arrows [ 50 icons ]
F *.*

Pictogram
F:
_cutting-severing-blade.svg
pictograms-aem-0001r-open_flame.svg
pictograms-aem-0002-hand_burn_from_chemical.svg
pictograms-aem-0003-pressurized_fluid.svg
pictograms-aem-0004-force_applied_to_hand-two_directions.svg
pictograms-aem-0005r-crush_of_whole_body-single_directional-pinned.svg
pictograms-aem-0006-force_applied_to_hand-one_direction.svg
pictograms-aem-0007-force_applied_to_foot.svg
pictograms-aem-0008-force_applied_to_lower_leg.svg
pictograms-aem-0009r-force_applied_to_body-two_directions.svg
pictograms-aem-0010-wear_ear_protection.svg
pictograms-aem-0011-belt_drive.svg
pictograms-aem-0012-gears.svg
pictograms-aem-0013-chain.svg
pictograms-aem-0014-toothed_belt.svg
pictograms-aem-0015-rotating_shaft.svg
pictograms-aem-0016-belt_drive.svg
pictograms-aem-0017-rollers.svg
pictograms-aem-0018-auger.svg
pictograms-aem-0019-gears.svg
pictograms-aem-0020-live_electrical_wire_contact.svg
pictograms-aem-0021-live_electrical_wire_contact.svg
pictograms-aem-0022-electric-general.svg
pictograms-aem-0023-explosive_material.svg
pictograms-aem-0024r-pressurized_fluid_or_gas.svg
pictograms-aem-0025-explosion-general.svg
pictograms-aem-0026r-battery_explosion.svg
pictograms-aem-0027r-battery_jump.svg
pictograms-aem-0028-engine_explosion.svg
pictograms-aem-0029-battery-explosion.svg
pictograms-aem-0030-force_applied_from_above.svg
pictograms-aem-0031-falling_tripping_forward.svg
pictograms-aem-0032-slipping_rearward.svg
pictograms-aem-0033-falling_from_machine.svg
pictograms-aem-0034-falling_from_height.svg
pictograms-aem-0035-falling_from_edge.svg
pictograms-aem-0036-falling_from_forks.svg
pictograms-aem-0031-falling_tripping_forward.svg
pictograms-aem-0032-slipping_rearward.svg
pictograms-aem-0033-falling_from_machine.svg
pictograms-aem-0034-falling_from_height.svg
pictograms-aem-0035-falling_from_edge.svg
pictograms-aem-0036-falling_from_forks.svg
pictograms-aem-0037-multiple_flying_objects-body.svg
pictograms-aem-0038-multiple_flying_objects-face.svg
pictograms-aem-0039-fasten_seat_belt.svg
pictograms-aem-0040-forage_harvester_cutterhead.svg
pictograms-aem-0041-foldable_rops.svg
pictograms-aem-0042-lock-out.svg
pictograms-aem-0043r-hot_surface.svg
pictograms-aem-0044-wait_until_moving_parts_h
pictograms-aem-0046-remove_key_and_read_service_manual_before_servicing.svg
pictograms-aem-0047-read_operators_manual.svg
pictograms-aem-0048-read_service_manual.svg
pictograms-aem-0049-maintain_proper_tire_pressure.svg
pictograms-aem-0050-keep_safe_distance_away_from_auger_area.svg
pictograms-aem-0051-do_not_operate_on_slope.svg
pictograms-aem-0052-hydraulic_cylinder_locking_device.svg
pictograms-aem-0053-attach_support_or_prop_to_lockout_for_service.svg
pictograms-aem-0054-radio_frequency_electromagnetic_radiation_hazard.svg
pictograms-aem-0055-laser_beam_hazard.svg
pictograms-aem-0056-radiation_hazard.svg
pictograms-aem-0057-biological_hazard.svg
pictograms-aem-0060-no_standing_in_this_area.svg
pictograms-aem-0061-no_step.svg
pictograms-aem-0062-dust-fumes_inhalation.svg
pictograms-aem-0063-wear_safety_boots.svg
pictograms-aem-0064-wear_eye_protection-safety_goggles.svg
pictograms-aem-0065r-wear_eye_protection-safety_glasses.svg
pictograms-aem-0066r-wear_head_protection-hard_hat.svg
pictograms-aem-0067-wear_face_protection-face_shield.svg
pictograms-aem-0068-wear_respirator-full_face.svg
pictograms-aem-0069r-do_not_touch_hot_surface.svg
pictograms-aem-0070-never_reach_into_pinch-pivot_area.svg
pictograms-aem-0071-no_riders-no_hangers_on.svg
pictograms-aem-0072-no_riders.svg
pictograms-aem-0073-wear_protective_gloves.svg
pictograms-aem-0074-pressurized_fluid-erosion_o_flesh.svg
pictograms-aem-0077-machine_rollover-no_rops.svg
pictograms-aem-0078-machine_rollover-with_rops.svg
pictograms-aem-0079-machine_runover_with_cutting_or_severing-blade.svg
pictograms-aem-0081-machine_runover.svg
pictograms-aem-0082-machine_runover-backover.svg
pictograms-aem-0083-never_reach_into_area_where_parts_are_in_motion.svg
pictograms-aem-0084-never_step_on_or_into_area_where_partsare_in_motion.svg
pictograms-aem-0085-keep_safe_distance_away_from_hazard.svg
pictograms-aem-0086-never_stand_in_unloading_area.svg
pictograms-aem-0087-never_stand_in_unloading_area.svg
pictograms-aem-0088-keep_safe_distance_away_from_pivot-articulation_area.svg
pictograms-aem-0089-never_reach_into_area_where_parts_are_in_motion.svg
pictograms-aem-0090-cutting-severing_of_fingers_or_hand-fan.svg
pictograms-aem-0091-cutting-severing_of_toes_or_foot-blade.svg
pictograms-aem-0092-cutting-severing_of_toes_or_foot-blade.svg
pictograms-aem-0093-cutting-severing_of_fingers_or_hand-blade.svg
pictograms-aem-0094-stored_energy_release-kickback.svg
pictograms-aem-0095r-keep_safe_distance_from_hot_surface.svg
pictograms-aem-0096-large_falling_object_from_above.svg
pictograms-aem-0097-wear_eye_protection-goggles.svg
pictograms-aem-0098-wear_eye_protection-safety_glasses.svg
pictograms-aem-0099-wear_face_protection-face_shield.svg
pictograms-aem-0101-811-prohibition_of_digging.svg
pictograms-aem-0102-no_open_flame.svg
pictograms-aem-0103-machine_run_over.svg
pictograms-aem-0104-no_smoking.svg
pictograms-aem-0105-keep_safe_distance_from_raised_loader_lift_arm_or_bucket.svg
pictograms-aem-0107-do_not_stand_under_raised_bucket.svg
pictograms-aem-0108-falling_from_bucket.svg
pictograms-aem-0109-hot_fluid_under_pressure.svg
pictograms-aem-0110-do_not_loosen_cap_until_cool.svg
pictograms-aem-0111-large_thrown_or_falling_object.svg
pictograms-aem-0112-wear-fasten_seat_belt-3_point.svg
pictograms-aem-0113-machine_run_over-tracked.svg
pictograms-aem-0114-crush_of_whole_body-force_applied_from_side.svg
pictograms-aem-0115-crush_of_whole_body-loader_bucket_or_lift_arm.svg
pictograms-aem-0116-crush_of_whole_body-excavator_or_turret-pinned.svg
pictograms-aem-0117-crush_of_whole_body-force_applied_from_side.svg
pictograms-aem-0118-crush_of_fingers_or_hand-force_applied_from_side.svg
pictograms-aem-0119-severing_of_fingers_or_hand-impeller_blade.svg
pictograms-aem-0120-severing_of_toes_or_foot-blade_or_cutter.svg
pictograms-aem-0121-severing_of_leg-blade_or_cutter.svg
pictograms-aem-0122-hand_or_arm_entanglement-auger.svg
pictograms-aem-0123-leg_or_foot_entanglement_or_sever-trencher.svg
pictograms-aem-0127-do_not_put_foot_in_this_area.svg
pictograms-aem-0128-arm_entanglement-broom_reel.svg
pictograms-aem-0130-keep_hand_safe_distance_from_hazard.svg

Maki
D  maki-12-base.svg
D  maki-18-base.svg
D  maki-24-base.svg
D  maki-icons.svg

EnergyGeneration
D  Energy-Icons.svg
D  Energy-InfrastructureIcons.svg
D  EnergyInkscapeTemplate.svg
D  Energy.svg
F Biomass_Icon.svg
F Biomass.svg
F CrudePipeline.svg
F NaturalGas_Icon.svg
F NaturalGas.svg
F NaturalGasTransmission.svg
F Petroluem_Icon.svg
F Petroluem.svg
F Nuclear.svg
F Solar_Icon.svg
F PumpedStorage_Icon.svg
F Tidal_Icon.svg
F Tidal.svg
F Transmission2.svg
F Wind_Icon.svg
F Wind.svg

Meterorology
D *.*

QGIS-svg/crosses [ 8 icons ]
Cross1.svg
Cross2.svg
Cross4.svg
Cross5.svg
Cross6.svg
Star1.svg
Star2.svg
Star3.svg

SJJB-OpenStreetMapIcons/food [ 11 icons ]
bar.sv
restaurant.svg

SJJB-OpenStreetMapIcons/sport [ 28 icons ]
F leisure_centre.svg
F gym.svg
F tennis.svg
