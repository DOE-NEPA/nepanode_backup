United Nations Office for the Coordination of Humanitarian Affairs (OCHA) Humanitarian Icons 2012
-------------------------------------------------------------------------------------------------

These are SVG versions of the Humanitarian Icons provided by UN OCHA in August 2012.

The original icons can be found at the original announcement on [ReliefWeb](http://reliefweb.int/map/world/world-humanitarian-and-country-icons-2012), and on [The Noun Project](http://thenounproject.com/collections/ocha-humanitarian-icons/).

Versions which have been optimized and hosted for use in online maps, by adding a blue or white background and by converting to 32, 64, and 100 pixel PNG images are available from [Google.org Crisis Response](http://mw1.google.com/crisisresponse/icons/un-ocha/index.html).

Whenever possible, credit as follows: “Source: OCHA”.