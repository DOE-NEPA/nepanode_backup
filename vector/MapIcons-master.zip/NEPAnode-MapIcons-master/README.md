NEPAnode-MapIcons
=================

A Collection of SVG Map Icons (i.e. Markers, Seals, Logos)
